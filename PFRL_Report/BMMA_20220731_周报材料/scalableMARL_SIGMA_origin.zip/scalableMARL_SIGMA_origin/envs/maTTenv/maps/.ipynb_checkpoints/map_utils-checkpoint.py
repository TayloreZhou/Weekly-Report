"""
Functions / Objects for occupancy grid maps.

!!IMPORTANT!! xy-rc coordinate relation:
2D map. (xmin, ymin) is located at the bottom left corner.
rows are counted from the bottom to top.
columns are counted from left to right.

Matplotlib.pyplot displays a matrix with (r,c)=(0,0) located at the top left.
Therefore, in the display_wrapper, the map is flipped.


Different usage of functions:
self.is_collision_ray_cell(*args,**kwargs) => 
            is_collision_ray_cell(MAP,*args,**kwargs)

is_collision
in_bound
is_blocked
get_front_obstacle
get_closest_obstacle
update_visit_freq_map
local_map_helper
local_map

"""
from cv2 import sqrt
import numpy as np
import yaml
import scipy.stats as st
import envs.maTTenv.util as util 

def round(x):
  if x >= 0:
    return int(x+0.5)
  else:
    return int(x-0.5)

class GridMap(object):
  def __init__(self, map_path, r_max=1.0, fov=np.pi, margin2wall=0.5):
    map_config = yaml.safe_load(open(map_path+".yaml", "r"))
    self.map = np.loadtxt(map_path+".cfg")
    if 'empty' in map_path:
      self.map = None
    else:
      self.map_linear = np.squeeze(self.map.astype(np.int8).reshape(-1, 1))
    self.mapdim = map_config['mapdim']
    self.mapres = np.array(map_config['mapres'])
    self.mapmin = np.array(map_config['mapmin'])
    self.mapmax = np.array(map_config['mapmax'])
    self.margin2wall = margin2wall
    self.origin = map_config['origin']
    self.r_max = r_max
    self.fov = fov

    # add belief_map
    self.belief_map = None

  # add functions about belief_map
  def reset_belief_map(self):
    self.belief_map = np.zeros(self.mapdim)
  
  def decay_belief_map(self, decay_factor):
    if self.belief_map is not None:
      self.belief_map *= decay_factor

  def se2_to_cell(self, pos):
    pos = pos[:2]
    cell_idx = (pos - self.mapmin)/self.mapres - 0.5
    return round(cell_idx[0]), round(cell_idx[1])

  def cell_to_se2(self, cell_idx):
    return ( np.array(cell_idx) + 0.5 ) * self.mapres + self.mapmin

def bresenham2D(sx, sy, ex, ey):
  """
  Bresenham's ray tracing algorithm in 2D from ESE650 2017 TA resources
  Inputs:
  (sx, sy)  start point of ray
  (ex, ey)  end point of ray
  Outputs:
    Indicies for x-axis and y-axis
  """
  sx = int(round(sx))
  sy = int(round(sy))
  ex = int(round(ex))
  ey = int(round(ey))
  dx = abs(ex-sx)
  dy = abs(ey-sy)
  steep = abs(dy)>abs(dx)
  if steep:
    dx,dy = dy,dx # swap

  if dy == 0:
    q = np.zeros((dx+1,1))
  else:
    q = np.append(0,np.greater_equal(np.diff(np.mod(np.arange( np.floor(dx/2), -dy*dx+np.floor(dx/2)-1,-dy),dx)),0))
  if steep:
    if sy <= ey:
      y = np.arange(sy,ey+1)
    else:
      y = np.arange(sy,ey-1,-1)
    if sx <= ex:
      x = sx + np.cumsum(q)
    else:
      x = sx - np.cumsum(q)
  else:
    if sx <= ex:
      x = np.arange(sx,ex+1)
    else:
      x = np.arange(sx,ex-1,-1)
    if sy <= ey:
      y = sy + np.cumsum(q)
    else:
      y = sy - np.cumsum(q)
  return np.vstack((x,y)).astype(np.int16)

def coord_change2g(vec, ang):
    assert(len(vec) == 2)
    # R * v
    return np.array([[np.cos(ang), -np.sin(ang)], [np.sin(ang), np.cos(ang)]])@vec

def is_collision_ray_cell(map_obj, cell):
  """
  cell : cell r, c index from left bottom.
  """
  idx = cell[0] + map_obj.mapdim[0] * cell[1]
  if (cell[0] < 0) or (cell[1] < 0) or (cell[0] >= map_obj.mapdim[0]) or (cell[1] >= map_obj.mapdim[1]):
    return True
  elif (map_obj.map is not None) and map_obj.map_linear[idx] == 1:
    return True
  else:
    return False
def is_blocked(map_obj, start_pos, end_pos):
  if map_obj.map is None:
    return False
  start_rc = map_obj.se2_to_cell(start_pos)
  end_rc = map_obj.se2_to_cell(end_pos)
  ray_cells = bresenham2D(start_rc[0], start_rc[1], end_rc[0], end_rc[1])
  i = 0
  while(i < ray_cells.shape[-1]):
    if is_collision_ray_cell(map_obj, ray_cells[:,i]):
        return True
    i += 1
  return False

def get_front_obstacle(map_obj, odom, **kwargs):
    ro_min_t = None
    start_rc = map_obj.se2_to_cell(odom[:2])
    end_pt_global_frame = coord_change2g(np.array([map_obj.r_max*np.cos(0.0), map_obj.r_max*np.sin(0.0)]), odom[-1]) + odom[:2]
    if map_obj.map is None:
      if not(in_bound(map_obj, end_pt_global_frame)):
        end_rc = map_obj.se2_to_cell(end_pt_global_frame)
        ray_cells = bresenham2D(start_rc[0], start_rc[1], end_rc[0], end_rc[1])
        i = 0
        while(i < ray_cells.shape[-1]):
          pt = map_obj.cell_to_se2(ray_cells[:,i])
          if not(in_bound(map_obj, pt)):
            break
          i += 1
        if i < ray_cells.shape[-1]: # break!
          ro_min_t = np.sqrt(np.sum(np.square(pt - odom[:2])))

    else:
      end_rc = map_obj.se2_to_cell(end_pt_global_frame)
      ray_cells = bresenham2D(start_rc[0], start_rc[1], end_rc[0], end_rc[1])
      i = 0
      while(i < ray_cells.shape[-1]): # break!
        if is_collision_ray_cell(map_obj, ray_cells[:,i]):
            break
        i += 1
      if i < ray_cells.shape[-1]:
        ro_min_t = np.sqrt(np.sum(np.square(map_obj.cell_to_se2(ray_cells[:,i]) - odom[:2])))

    if ro_min_t is None:
        return None
    else:
        return ro_min_t, 0.0

def distance_map(map_obj,start_rc):
  cur_dist_map = np.zeros(map_obj.mapdim)
  direction_vec = np.array([[0,1],[0,-1],[1,0],[-1,0]])
  # nearest matching
  if is_collision_ray_cell(map_obj,start_rc):
    cur_list = set()
    next_list = set()
    close_list = set()
    cur_list.add(tuple(start_rc))
    flag = True
    while cur_list and flag:
      for pos in cur_list:
        close_list.add(pos)
        pos = np.array(pos)
        for vec in direction_vec:
          next_pos = tuple(vec+pos)
          if next_pos in close_list:
            continue
          if is_collision_ray_cell(map_obj,next_pos):
            next_list.add(next_pos)
          else:
            start_rc = next_pos
            flag = False
            break
        if not flag:
          break
      cur_list = next_list
      next_list = set()
  cur_list = set()
  next_list = set()
  close_list = set()
  cur_list.add(tuple(start_rc))
  md_counter = 1
  cur_dist_map[start_rc] = -1
  while cur_list:
    for pos in cur_list:
      close_list.add(pos)
      pos = np.array(pos)
      for vec in direction_vec:
        next_pos = tuple(vec+pos)
        if is_collision_ray_cell(map_obj,next_pos):
          continue
        if next_pos not in close_list:
          cur_dist_map[next_pos] = md_counter
          next_list.add(next_pos)
    md_counter += 1
    cur_list = next_list
    next_list = set()
  return cur_dist_map, start_rc

def func_map(map_obj,func):
  cur_func_map = np.zeros(map_obj.mapdim)
  for x in range(map_obj.mapdim[0]):
    for y in range(map_obj.mapdim[1]):
      pos_se = map_obj.cell_to_se2((x,y))
      cur_func_map[x,y] = func(pos_se)
  # cur_func_map = min_max_scale(cur_func_map)
  # count = [(cur_func_map>0.2*i).sum() for i in range(1,6)]
  # print('func buf',(cur_func_map!=0).sum(),count)
  return cur_func_map

def cos_similarity(v_a,v_b):
  dot_product = 0.0
  normA = 0.0
  normB = 0.0
  for a,b in zip(v_a,v_b):
      dot_product += a*b
      normA += a**2
      normB += b**2
  if normA == 0.0 or normB==0.0:
      return 1
  else:
      return dot_product / ((normA*normB)**0.5)

def update_belief_map(map_obj, agents, targets, nb_agents, nb_targets, max_speed=2.0):
  distance_list_agents = []
  distance_list_targets = []
  start_rc_targets = []
  speed_prob_norm = []
  id_matrix = np.eye(len(targets[0].cov),len(targets[0].cov))
  filter_covs = [ targets[i].cov.copy()*id_matrix for i in range(nb_targets)]
  filter_xy_pdf = [ st.multivariate_normal(mean=targets[i].state[:2], cov=filter_covs[i][:2,:2]) for i in range(len(filter_covs))]
  # filter_speed_pdf = [ st.multivariate_normal(mean=targets[i].state[2:], cov=filter_covs[i][2:,2:]) for i in range(len(filter_covs))]
  for i in range(nb_agents):
    start_rc = map_obj.se2_to_cell(agents[i].state[:2])
    distance_list_agents.append(distance_map(map_obj, start_rc)[0])
  for i in range(nb_targets):
    start_rc = map_obj.se2_to_cell(targets[i].state[:2])
    dm ,sc = distance_map(map_obj, start_rc)
    distance_list_targets.append(dm)
    start_rc_targets.append(sc)
    func = lambda pos_se: np.exp(np.sqrt((targets[i].state[2:4]**2).sum())/(2**0.5*max_speed)*cos_similarity(pos_se-targets[i].state[:2], targets[i].state[2:4]))
    speed_prob_norm.append(func_map(map_obj,func))

  belief_buf = np.zeros(map_obj.mapdim)
  for x in range(map_obj.mapdim[0]):
    for y in range(map_obj.mapdim[1]):
      if is_collision_ray_cell(map_obj,(x,y)):
          continue
      pos_se = map_obj.cell_to_se2((x,y))
      belief_target = 0
      # target information
      # Part1, Filter Prob. 
      # Part2, velocity. 
      for i in range(nb_targets):
        rela_pos = pos_se-targets[i].state[:2]
        punish_ratio = abs(np.array([x,y])-np.array(start_rc_targets[i])).sum()/distance_list_targets[i][(x,y)] if distance_list_targets[i][(x,y)]>0 else 1
        assert punish_ratio <= 1
        filter_xy_prob = punish_ratio*filter_xy_pdf[i].pdf(pos_se)
        # filter_speed_prob = punish_ratio*filter_speed_pdf[i].pdf(rela_pos/sample_rate)
        # belief_target += filter_xy_prob*filter_speed_prob
        belief_target += filter_xy_prob*speed_prob_norm[i][x,y]
        # belief_target += filter_xy_prob

      # agent information
      # Part3, angle. 
      # Part4, distance.
      certainty_agent = 1
      for i in range(nb_agents):
        r, alpha = util.relative_distance_polar(pos_se[:2],
                                              xy_base=agents[i].state[:2], 
                                              theta_base=agents[i].state[2])
        p_fov = .5*map_obj.fov/max(abs(alpha),.5*map_obj.fov)
        p_dist = map_obj.r_max/max(r,map_obj.r_max)
        assert p_fov <= 1 and p_dist <= 1
        punish_ratio = abs(np.array([x,y])-np.array(map_obj.se2_to_cell(agents[i].state[:2]))).sum()/distance_list_agents[i][(x,y)] if distance_list_agents[i][(x,y)]>0 else 1
        certainty_agent *= np.exp(punish_ratio*p_fov*p_dist-1)
      belief_buf[x][y] += belief_target*certainty_agent
  belief_buf = min_max_scale(belief_buf)
  # map_obj.belief_map += belief_buf
  map_obj.belief_map = belief_buf
  # reward construct
  # return belief_sum/belief_buf.sum() if belief_buf.sum() != 0 else 0

def belief_map_helper(map_obj, belief_norm, im_size, odom, local_mapmin, R, get_belief=False):
  """
  Helper function to generate a local map from the global map.
  For the visit frequency local map, it assigns 2.0 for an obstacle cell,
  and a value in (0,1) for an empty cell with its visit frequency value.
  """
  local_map = np.zeros((im_size, im_size))
  local_belief_map = np.zeros((im_size, im_size)) if get_belief else None
  for r in range(im_size):
    for c in range(im_size):
      xy_local = cell_to_se2([r,c], local_mapmin, map_obj.mapres)
      xy_global = np.matmul(R, xy_local) + odom[:2]
      cell_global = map_obj.se2_to_cell(xy_global)
      local_map[c,r] = int(is_collision_ray_cell(map_obj,cell_global))
      if get_belief:
        # Cells with an obstacle have 2.0. Others have visit frequency value from the global map.
        if local_map[c,r] == 1 :
          local_belief_map[c,r] = -1.0
        elif in_bound(map_obj,xy_global):
          local_belief_map[c,r] = belief_norm[cell_global[0], cell_global[1]]
  return local_map, local_belief_map

def min_max_scale(map):
  return (map-map.min())/(map.max()-map.min()) if map.max()-map.min()>0 else map

def local_belief_map(map_obj, im_size, odom, get_belief=True):
  """
  Return a local visit frequency map around the odom. odom position should
  be the center.
  Parameters:
  ---------
  im_size : the number of rows/columns
  """
  R=np.array([[np.cos(odom[2] - np.pi/2), -np.sin(odom[2] - np.pi/2)],
            [np.sin(odom[2] - np.pi/2), np.cos(odom[2] - np.pi/2)]])
  local_mapmin = np.array([-im_size/2*map_obj.mapres[0], -im_size/2*map_obj.mapres[0]])
  belief_norm = min_max_scale(map_obj.belief_map)
  return belief_map_helper(map_obj, belief_norm,im_size, odom, local_mapmin, R, get_belief)

def local_belief_map_surroundings(map_obj, im_size, odom):
  """
  Return local visit frequency map of the surrounding areas.
  """
  R=np.array([[np.cos(odom[2] - np.pi/2), -np.sin(odom[2] - np.pi/2)],
            [np.sin(odom[2] - np.pi/2), np.cos(odom[2] - np.pi/2)]])
  local_belief_maps = []
  local_mapmin = [ # From left, right, front, back
    np.array([-im_size/2*3*map_obj.mapres[0], 0.0]),
    np.array([im_size/2*map_obj.mapres[0], 0.0]),
    np.array([-im_size/2*map_obj.mapres[0], im_size*map_obj.mapres[1]]),
    np.array([-im_size/2*map_obj.mapres[0], -im_size*map_obj.mapres[1]]),
    ]
  belief_norm = min_max_scale(map_obj.belief_map)
  for i in range(4):
    _, local_map_belief_i = belief_map_helper(map_obj, belief_norm,im_size,
                                                odom, local_mapmin[i], R,
                                                get_belief=True)
    local_belief_maps.append(local_map_belief_i)
  return None, np.array(local_belief_maps)

def update_global_map(map_obj, im_size):
  scale_r = (map_obj.mapdim[0] + im_size - 1) / im_size
  scale_c = (map_obj.mapdim[1] + im_size - 1) / im_size
  global_map_tmp = np.zeros((im_size, im_size))
  belief_norm = min_max_scale(map_obj.belief_map)
  for r in range(map_obj.mapdim[0]):
    for c in range(map_obj.mapdim[1]):
      r_g = int(r / scale_r)
      c_g = int(c / scale_c)
      global_map_tmp[c_g,r_g] += belief_norm[r, c]
  map_obj.global_belief = global_map_tmp

def get_global_map(map_obj):
  assert map_obj.global_belief is not None
  assert not np.isnan(map_obj.global_belief.max())
  return min_max_scale(map_obj.global_belief)

def get_closest_obstacle(map_obj, odom, ang_res=0.05):
  """
    Return the closest obstacle/boundary cell
  """
  ang_grid = np.arange(-.5*map_obj.fov, .5*map_obj.fov, ang_res)
  closest_obstacle = (map_obj.r_max, 0.0)
  start_rc = map_obj.se2_to_cell(odom[:2])
  for ang in ang_grid:
    end_pt_global_frame = coord_change2g(np.array([map_obj.r_max*np.cos(ang), map_obj.r_max*np.sin(ang)]), odom[-1]) + odom[:2]

    if map_obj.map is None:
      if not(in_bound(map_obj, end_pt_global_frame)):
        end_rc = map_obj.se2_to_cell(end_pt_global_frame)
        ray_cells = bresenham2D(start_rc[0], start_rc[1], end_rc[0], end_rc[1])
        i = 0
        while(i < ray_cells.shape[-1]):
          pt = map_obj.cell_to_se2(ray_cells[:,i])
          if not(in_bound(map_obj, pt)):
            break
          i += 1
        if i < ray_cells.shape[-1]: # break!
          ro_min_t = np.sqrt(np.sum(np.square(pt - odom[:2])))
          if ro_min_t < closest_obstacle[0]:
            closest_obstacle = (ro_min_t, ang)

    else:
      end_rc = map_obj.se2_to_cell(end_pt_global_frame)
      ray_cells = bresenham2D(start_rc[0], start_rc[1], end_rc[0], end_rc[1])
      i = 0
      while(i < ray_cells.shape[-1]): # break!
        if is_collision_ray_cell(map_obj, ray_cells[:,i]):
            break
        i += 1
      if i < ray_cells.shape[-1]:
        ro_min_t = np.sqrt(np.sum(np.square(map_obj.cell_to_se2(ray_cells[:,i]) - odom[:2])))
        if ro_min_t < closest_obstacle[0]:
          closest_obstacle = (ro_min_t, ang)

  if closest_obstacle[0] == map_obj.r_max:
    return None
  else:
    return closest_obstacle

def is_collision(map_obj, pos):
  if not(in_bound(map_obj, pos)):
    return True
  else:
    if map_obj.map is not None:
      n = np.ceil(map_obj.margin2wall/map_obj.mapres).astype(np.int16)
      cell = np.minimum([map_obj.mapdim[0]-1,map_obj.mapdim[1]-1] , map_obj.se2_to_cell(pos))
      for r_add in np.arange(-n[1],n[1],1):
        for c_add in np.arange(-n[0],n[0],1):
          x_c = np.clip(cell[0]+r_add, 0, map_obj.mapdim[0]-1).astype(np.int16)
          y_c = np.clip(cell[1]+c_add,0,map_obj.mapdim[1]-1).astype(np.int16)
          idx = x_c + map_obj.mapdim[0] * y_c
          if map_obj.map_linear[idx] == 1:
            return True
  return False

def in_bound(map_obj, pos):
  return not((pos[0] < map_obj.mapmin[0] + map_obj.margin2wall)
    or (pos[0] > map_obj.mapmax[0] - map_obj.margin2wall)
    or (pos[1] < map_obj.mapmin[1] + map_obj.margin2wall)
    or (pos[1] > map_obj.mapmax[1] - map_obj.margin2wall))

def se2_to_cell(pos, mapmin, mapres):
  pos = pos[:2]
  cell_idx = (pos - mapmin)/mapres - 0.5
  return round(cell_idx[0]), round(cell_idx[1])

def cell_to_se2(cell_idx, mapmin, mapres):
  return ( np.array(cell_idx) + 0.5 ) * mapres + mapmin

def se2_to_cell_batch(pos, mapmin, mapres):
  """
  Coversion for Batch input : pos = [batch_size, 2 or 3]

  OUTPUT: [batch_size,], [batch_size,]
  """
  return round((pos[:,0] - mapmin[0])/mapres[0] - 0.5), round((pos[:,1] - mapmin[1])/mapres[1] - 0.5)

def cell_to_se2_batch(cell_idx, mapmin, mapres):
  """
  Coversion for Batch input : cell_idx = [batch_size, 2]

  OUTPUT: [batch_size, 2]
  """
  return (cell_idx[:,0] + 0.5) * mapres[0] + mapmin[0], (cell_idx[:,1] + 0.5) * mapres[1] + mapmin[1]

def generate_trajectory(map_obj):
  import matplotlib
  matplotlib.use('TkAgg')
  from matplotlib import pyplot as plt
  from scipy.interpolate import interp1d

  ax = plt.gca()
  fig = plt.gcf()
  implot = ax.imshow(map_obj.map, cmap='gray_r', origin='lower', extent=[map_obj.mapmin[0], map_obj.mapmax[0], map_obj.mapmin[1], map_obj.mapmax[1]])

  path_points = []
  def onclick(event):
    if event.xdata != None and event.ydata != None:
      ax.plot(event.xdata, event.ydata, 'ro')
      plt.draw()
      path_points.append([event.xdata, event.ydata])
  cid = fig.canvas.mpl_connect('button_press_event', onclick)

  plt.show()
  print("%d points selected"%len(path_points))
  path_points = np.array(path_points)
  interpol_num = 5
  passed = False
  vel = 0.2
  T_step = 100
  while(not passed):
    ax = plt.gca()
    fig = plt.gcf()
    implot = ax.imshow(map_obj.map, cmap='gray_r', origin='lower', extent=[map_obj.mapmin[0], map_obj.mapmax[0], map_obj.mapmin[1], map_obj.mapmax[1]])

    sorted_paths = []
    newx = []
    newy = []

    t_done = False
    t = 1
    while(not t_done):
      tmp = [path_points[t-1]]
      tmp_x = []
      while((path_points[t-1,0] < path_points[t,0])):
        tmp.append(path_points[t])
        distance = np.sqrt(np.sum(np.square( path_points[t] - path_points[t-1] )))
        num = distance / (0.5 * vel)
        tmp_x.extend(np.linspace(path_points[t-1,0], path_points[t,0], num=num, endpoint=False))
        t += 1
        if t >= len(path_points):
          t_done = True
          break
      if len(tmp) > 1:
        tmp = np.array(tmp)
        f0 = interp1d(tmp[:,0], tmp[:,1], kind='cubic')
        newx.extend(tmp_x)
        newy.extend(f0(np.array(tmp_x)))
        sorted_paths.append(tmp)
        if t_done:
          break

      tmp = [path_points[t-1]]
      tmp_x = []
      while((path_points[t-1,0] >= path_points[t,0])):
        tmp.append(path_points[t])
        distance = np.sqrt(np.sum(np.square( path_points[t] - path_points[t-1] )))
        num = distance / (0.5 * vel)
        tmp_x.extend(np.linspace(path_points[t-1,0], path_points[t,0], num=num, endpoint=False))
        t += 1
        if t >= len(path_points):
          t_done = True
          break
      tmp = np.array(tmp)
      f0 = interp1d(np.flip(tmp[:,0], -1), np.flip(tmp[:,1], -1), kind='cubic')
      newx.extend(tmp_x)
      newy.extend(f0(np.array(tmp_x)))
      sorted_paths.append(tmp)

    ax.plot(path_points[:,0], path_points[:,1],'ro')
    ax.plot(newx, newy,'b.')
    print("Total point number: %d"%len(newx))
    plt.show()
    if len(newx) > T_step:
      passed = True
    else:
      interpol_num += 1
  newx = np.array(newx)
  newy = np.array(newy)
  x_vel = (newx[1:]-newx[:-1])/0.5
  y_vel = (newy[1:]-newy[:-1])/0.5
  theta = np.arctan2(newy[1:]-newy[:-1], newx[1:]-newx[:-1])

  final = np.concatenate((newx[:-1, np.newaxis], newy[:-1, np.newaxis], theta[:,np.newaxis], x_vel[:,np.newaxis], y_vel[:,np.newaxis]), axis=1)
  np.save(open("path_sh_1.npy", "wb"), final)


def generate_map(mapname, mapdim=(52,52), mapres=1):
  new_map = np.zeros((int(mapdim[0]/mapres), int(mapdim[1]/mapres)), dtype=np.int8)
  """
  0 0 0 0
  0 1 0 0
  0 0 0 0
  0 0 1 0
  0 0 0 0
  0 1 0 0
  0 1 0 0
  0 0 0 0
  """
  # Boundary
  new_map[0,:] = 1.0
  new_map[:,0] = 1.0
  new_map[-1,:] = 1.0
  new_map[:,-1] = 1.0

  # Obstacles
  new_map[15:25, 20:30] = 1.0
  new_map[40:30, 10:20] = 1.0
  new_map[25:30, 30:40] = 1.0

  new_map = new_map.astype(np.int8)
  print(new_map.shape)
  np.savetxt(mapname, new_map, fmt='%d')

if __name__ == '__main__':
  generate_map('small.cfg')
  # import time
  # start = time.time()
  # for i in range(10000):
  #   p = st.multivariate_normal.pdf([10,10],mean=[5,10],cov=5*np.eye(2,2))
  # end = time.time()
  # print(end-start)
  # start = time.time()
  # p_dist = st.multivariate_normal(mean=[5,10],cov=5*np.eye(2,2))
  # for i in range(10000):
  #   p = p_dist.pdf([10,10])
  # end = time.time()
  # print(end-start)
  # import os
  # from envs.maTTenv.metadata import METADATA
  # map_dir_path = '/'.join(__file__.split('/')[:-1])
  # MAP = GridMap(
  #     map_path=os.path.join(map_dir_path, 'test'), 
  #     r_max = 10, fov = 90/180.0*np.pi,
  #     margin2wall = METADATA['margin2wall'])
  # MAP.reset_belief_map()
  # MAP.reset_scan_map()
  # MAP.scan_map = np.ones(MAP.mapdim)
  # update_belief_map(MAP,np.array([20.0,10.0,0.5,0.5]),np.array([[100,0,0,0],[0,100,0,0],[0,0,100,0],[0,0,0,50]]))
  # import matplotlib.pyplot as plt
  # fig = plt.figure()
  # ax = fig.subplots()

  # im = ax.imshow(MAP.map, cmap='gray_r', origin='lower',
  #                   extent=[MAP.mapmin[0], MAP.mapmax[0], MAP.mapmin[1], MAP.mapmax[1]])
  # im = ax.imshow(MAP.belief_map.T, cmap='Greens', alpha=0.5, origin='lower',
  #                   extent=[MAP.mapmin[0], MAP.mapmax[0], MAP.mapmin[1], MAP.mapmax[1]])
  
  # ax.plot(20, 10, marker='o', markersize=5, 
  #                   linestyle='None', markerfacecolor='r', markeredgecolor='r')
  # ax.plot(20, 10, marker='o', markersize=10, 
  #                   linewidth=5, markerfacecolor='none', markeredgecolor='g')
  # ax.set_xlim((MAP.mapmin[0], MAP.mapmax[0]))
  # ax.set_ylim((MAP.mapmin[1], MAP.mapmax[1]))
  # ax.set_aspect('equal','box')
  # ax.grid()

  # plt.show()