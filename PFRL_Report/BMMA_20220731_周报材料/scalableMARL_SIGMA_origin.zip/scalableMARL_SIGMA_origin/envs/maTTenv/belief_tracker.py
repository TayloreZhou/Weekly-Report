"""Belief Trackers

KFbelief : Belief Update using Kalman Filter
UKFbelief : Belief Update using Unscented Kalman Filter using filterpy library
"""
from operator import length_hint
from cv2 import mean
import numpy as np
import math
from numpy import cov, linalg as LA
import envs.maTTenv.util as util
from gym.utils import seeding
import scipy.stats as st

from filterpy.kalman import JulierSigmaPoints, UnscentedKalmanFilter, ExtendedKalmanFilter

def calc_covariance(px, pw):
    return np.cov(px.T) 

class PFbelief(object):
    """
    Particle Filter for the target tracking problem.
    """
    def __init__(self, agent_id, dim, limit, dim_z=2, n_particles=200, multi_step = 0, A=None, W=None,
                    obs_noise_func=None, collision_func=None):
        self.agent_id = agent_id
        self.dim = dim
        self.limit = limit
        self.n_particles = n_particles
        self.multi_step = multi_step
        self.NTh = n_particles/2.0
        self.A = np.eye(self.dim) if A is None else A
        self.W = W if W is not None else np.zeros((self.dim, self.dim))
        self.obs_noise_func = obs_noise_func
        self.collision_func = collision_func
        self.cov = np.eye(self.dim)
        self.np_random, _ = seeding.np_random(None)
    
    def multi_step_predict(self):
        multi_step_info = []
        for i in range(self.multi_step):
            t_i = np.zeros_like(self.particles)
            for i in range(self.n_particles):
                state_pi = self.particles[i]
                new_state_pi = np.matmul(self.A, state_pi)
                noise_sample = np.random.multivariate_normal(np.zeros(self.dim,), self.W)
                new_state_pi += noise_sample
                if self.collision_func(new_state_pi[:2]):
                    new_state_pi = self.collision_control(new_state_pi, state_pi)
                t_i[i] = np.clip(new_state_pi, self.limit[0], self.limit[1])
            multi_step_info.append(t_i.T.dot(self.weights))
        return multi_step_info

    def reset(self, init_state, init_cov):
        self.state = init_state
        self.cov = init_cov*np.eye(self.dim)
        particles = np.zeros((0, self.dim))
        for _ in range(self.n_particles):
            noise_sample = np.random.multivariate_normal(np.zeros(self.dim,), self.W)
            particles = np.vstack((particles,self.state + noise_sample))
        self.particles = particles
        self.weights = np.array([1/self.n_particles] * self.n_particles)
        return self.multi_step_predict()

    def predict(self):
        #state_new = np.matmul(self.A, self.state)
        for i in range(self.n_particles):
            state_pi = self.particles[i]
            new_state_pi = np.matmul(self.A, state_pi)
            noise_sample = np.random.multivariate_normal(np.zeros(self.dim,), self.W)
            new_state_pi += noise_sample
            if self.collision_func(new_state_pi[:2]):
                new_state_pi = self.collision_control(new_state_pi, state_pi)
            self.particles[i] = np.clip(new_state_pi, self.limit[0], self.limit[1])
        state_new = self.particles.T.dot(self.weights)
        self.state = np.clip(state_new, self.limit[0], self.limit[1])
        cov_new = calc_covariance(self.particles, self.weights)
        if LA.det(cov_new) > 0:
            self.cov = cov_new
        else:
            print('wrong pre.')
        return self.multi_step_predict()
    
    def collision_control(self, new_state, old_state):
        new_state[0] = old_state[0]
        new_state[1] = old_state[1]
        if self.dim > 2:
            new_state[2] = -2 * .2 * new_state[2] + np.random.normal(0.0, 0.2)#-0.001*np.sign(new_state[2])
            new_state[3] = -2 * .2 * new_state[3] + np.random.normal(0.0, 0.2)#-0.001*np.sign(new_state[3])
        return new_state
    
    def re_sampling(self):
        """
        low variance re-sampling
        """
        w_cum = np.cumsum(self.weights)
        base = np.arange(0.0, 1.0, 1 / self.n_particles)
        re_sample_id = base + np.random.uniform(0, 1 / self.n_particles)
        indexes = []
        ind = 0
        for ip in range(self.n_particles):
            while re_sample_id[ip] > w_cum[ind]:
                ind += 1
            indexes.append(ind)
        self.particles = self.particles[indexes,:]
        self.weights = np.array([1/self.n_particles] * self.n_particles)
        if np.isnan(self.weights.sum()): print('no weights after re-sample')

    def update(self, z_t, x_t):
        # r_c, alpha_c = util.relative_distance_polar(t_t[:2],
        #                                     xy_base=x_t[:2], 
        #                                     theta_base=x_t[2]) 
        re_dist = 1
        while True: 
            for i in range(self.n_particles):
                p_i = self.particles[i]
                w = self.weights[i]
                r_pred, alpha_pred = util.relative_distance_polar(
                            p_i[:2], x_t[:2], x_t[2])
                dz = np.array([r_pred, alpha_pred]) - z_t
                dz[1] = util.wrap_around(dz[1])
                obs_noise = self.obs_noise_func((r_pred, alpha_pred))
                prob = st.multivariate_normal.pdf(dz, mean=np.zeros(2,), cov=obs_noise)
                w *= prob
                # for j in range(len(dz)):
                #     w *= gauss_likelihood(dz[j], obs_noise[j][j])
                self.weights[i] = w
            
            if self.weights.sum() >= 1e-6:
                re_dist = 1
                break
            else:
                obs_state = util.polar_distance_relative(z_t[0], z_t[1], x_t[2]) + x_t[:2]
                
                for i in range(self.n_particles):
                    self.particles[i][0] = obs_state[0]
                    self.particles[i][1] = obs_state[1]
                    noise_sample = np.random.multivariate_normal(np.zeros(self.dim,), self.W*math.floor(re_dist/4+1))
                    self.particles[i] += noise_sample
                self.weights = np.array([1/self.n_particles] * self.n_particles)
                cov_new = calc_covariance(self.particles, self.weights)
                re_dist += 1
            if re_dist > 4:
                print('Hard Noise')
        self.weights = self.weights/self.weights.sum()
        state_new = self.particles.T.dot(self.weights)
        self.state = np.clip(state_new, self.limit[0], self.limit[1])

        # Resampling
        # N_eff = 1.0 / (self.weights.dot(self.weights.T))
        # if N_eff < self.NTh:
        self.re_sampling()
        cov_new = calc_covariance(self.particles, self.weights)
        if LA.det(cov_new) > 0:
            self.cov = cov_new
        else:
            print('wrong up.')

class KFbelief(object):
    """
    Kalman Filter for the target tracking problem.

    state : target state
    x : agent state
    z : observation (r, alpha)
    """
    def __init__(self, agent_id, dim, limit, dim_z=2, A=None, W=None,
                    obs_noise_func=None, collision_func=None):
        """
        dim : dimension of state
        limit : An array of two vectors.
                limit[0] = minimum values for the state,
                limit[1] = maximum value for the state
        dim_z : dimension of observation,
        A : state transition matrix
        W : state noise matrix
        obs_noise_func : observation noise matrix function of z
        collision_func : collision checking function
        """
        self.agent_id = agent_id
        self.dim = dim
        self.limit = limit
        self.A = np.eye(self.dim) if A is None else A
        self.W = W if W is not None else np.zeros((self.dim, self.dim))
        self.obs_noise_func = obs_noise_func
        self.collision_func = collision_func
        self.cov = np.eye(self.dim)

    def reset(self, init_state, init_cov):
        self.state = init_state
        self.cov = init_cov*np.eye(self.dim)

    def predict(self):
        # Prediction
        state_new = np.matmul(self.A, self.state)
        cov_new = np.matmul(np.matmul(self.A, self.cov), self.A.T) +  self.W
        if True: # LA.det(cov_new) < 1e6:
            self.cov = cov_new
        self.state = np.clip(state_new, self.limit[0], self.limit[1])

    def update(self, z_t, x_t):
        """
        Parameters
        --------
        z_t : observation - radial and angular distances from the agent.
        x_t : agent state (x, y, orientation) in the global frame.
        """
        # Kalman Filter Update
        r_pred, alpha_pred = util.relative_distance_polar(
                        self.state[:2], x_t[:2], x_t[2])
        diff_pred = self.state[:2] - x_t[:2]
        if self.dim == 2:
            Hmat = np.array([[diff_pred[0],diff_pred[1]],
                        [-diff_pred[1]/r_pred, diff_pred[0]/r_pred]])/r_pred
        elif self.dim == 4:
            Hmat = np.array([[diff_pred[0], diff_pred[1], 0.0, 0.0],
              [-diff_pred[1]/r_pred, diff_pred[0]/r_pred, 0.0, 0.0]])/r_pred
        else:
            raise ValueError('target dimension for KF must be either 2 or 4')
        innov = z_t - np.array([r_pred, alpha_pred])
        innov[1] = util.wrap_around(innov[1])

        R = np.matmul(np.matmul(Hmat, self.cov), Hmat.T) \
                                + self.obs_noise_func((r_pred, alpha_pred))
        K = np.matmul(np.matmul(self.cov, Hmat.T), LA.inv(R))
        C = np.eye(self.dim) - np.matmul(K, Hmat)

        cov_new = np.matmul(C, self.cov)
        state_new = self.state +  np.matmul(K, innov)

        if True: #LA.det(cov_new) < 1e6:
            self.cov = cov_new
        self.state = np.clip(state_new, self.limit[0], self.limit[1])


class UKFbelief(object):
    """
    Unscented Kalman Filter from filterpy
    """
    def __init__(self, dim, limit, dim_z=2, fx=None, W=None, obs_noise_func=None,
                    collision_func=None, sampling_period=0.5, kappa=1):
        """
        dim : dimension of state
            ***Assuming dim==3: (x,y,theta), dim==4: (x,y,xdot,ydot), dim==5: (x,y,theta,v,w)
        limit : An array of two vectors. limit[0] = minimum values for the state,
                                            limit[1] = maximum value for the state
        dim_z : dimension of observation,
        fx : x_tp1 = fx(x_t, dt), state dynamic function
        W : state noise matrix
        obs_noise_func : observation noise matrix function of z
        collision_func : collision checking function
        n : the number of sigma points
        """
        self.dim = dim
        self.limit = limit
        self.W = W if W is not None else np.zeros((self.dim, self.dim))
        self.obs_noise_func = obs_noise_func
        self.collision_func = collision_func

        def hx(y, agent_state, measure_func=util.relative_distance_polar):
            r_pred, alpha_pred = measure_func(y[:2], agent_state[:2],
                                                                agent_state[2])
            return np.array([r_pred, alpha_pred])

        def x_mean_fn_(sigmas, Wm):
            if dim == 3:
                x = np.zeros(dim)
                sum_sin, sum_cos = 0., 0.
                for i in range(len(sigmas)):
                    s = sigmas[i]
                    x[0] += s[0] * Wm[i]
                    x[1] += s[1] * Wm[i]
                    sum_sin += np.sin(s[2])*Wm[i]
                    sum_cos += np.cos(s[2])*Wm[i]
                x[2] = np.arctan2(sum_sin, sum_cos)
                return x
            elif dim == 5:
                x = np.zeros(dim)
                sum_sin, sum_cos = 0., 0.
                for i in range(len(sigmas)):
                    s = sigmas[i]
                    x[0] += s[0] * Wm[i]
                    x[1] += s[1] * Wm[i]
                    x[3] += s[3] * Wm[i]
                    x[4] += s[4] * Wm[i]
                    sum_sin += np.sin(s[2])*Wm[i]
                    sum_cos += np.cos(s[2])*Wm[i]
                x[2] = np.arctan2(sum_sin, sum_cos)
                return x
            else:
                return None

        def z_mean_fn_(sigmas, Wm):
            x = np.zeros(dim_z)
            sum_sin, sum_cos = 0., 0.
            for i in range(len(sigmas)):
                s = sigmas[i]
                x[0] += s[0] * Wm[i]
                sum_sin += np.sin(s[1])*Wm[i]
                sum_cos += np.cos(s[1])*Wm[i]
            x[1] = np.arctan2(sum_sin, sum_cos)
            return x

        def residual_x_(x, xp):
            """
            x : state, [x, y, theta]
            xp : predicted state
            """
            if dim == 3 or dim == 5:
                r_x = x - xp
                r_x[2] = util.wrap_around(r_x[2])
                return r_x
            else:
                return None

        def residual_z_(z, zp):
            """
            z : observation, [r, alpha]
            zp : predicted observation
            """
            r_z = z - zp
            r_z[1] = util.wrap_around(r_z[1])
            return r_z

        sigmas = JulierSigmaPoints(n=dim, kappa=kappa)

        self.ukf = UnscentedKalmanFilter(dim, dim_z, sampling_period, fx=fx,
                    hx=hx, points=sigmas, x_mean_fn=x_mean_fn_,
                    z_mean_fn=z_mean_fn_, residual_x=residual_x_,
                    residual_z=residual_z_)

    def reset(self, init_state, init_cov):
        self.state = init_state
        self.cov = init_cov*np.eye(self.dim)
        self.ukf.x = self.state
        self.ukf.P = self.cov
        self.ukf.Q = self.W # process noise matrix

    def update(self, observed, z_t, x_t, u_t=None):
        # Kalman Filter Update
        self.ukf.predict(u=u_t)

        if observed:
            r_pred, alpha_pred = util.relative_distance_polar(self.ukf.x[:2], x_t[:2], x_t[2])
            self.ukf.update(z_t, R=self.obs_noise_func((r_pred, alpha_pred)),
                                agent_state=x_t)

        cov_new = self.ukf.P
        state_new = self.ukf.x

        if LA.det(cov_new) < 1e6:
            self.cov = cov_new
        if not(self.collision_func(state_new[:2])):
            self.state = np.clip(state_new, self.limit[0], self.limit[1])
