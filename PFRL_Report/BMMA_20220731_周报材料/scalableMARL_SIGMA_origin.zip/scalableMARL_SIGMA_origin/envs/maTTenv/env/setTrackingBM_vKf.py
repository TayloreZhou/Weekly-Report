import os, copy, pdb
import math
import numpy as np
from numpy import linalg as LA
from gym import spaces, logger
from envs.maTTenv.maps import map_utils
import envs.maTTenv.util as util 
from envs.maTTenv.agent_models import *
from envs.maTTenv.belief_tracker import KFbelief, PFbelief
from envs.maTTenv.metadata import METADATA
from envs.maTTenv.env.maTracking_Base import maTrackingBase

"""
Target Tracking Environments for Reinforcement Learning.
[Variables]

d: radial coordinate of a belief target in the learner frame
alpha : angular coordinate of a belief target in the learner frame
ddot : radial velocity of a belief target in the learner frame
alphadot : angular velocity of a belief target in the learner frame
Sigma : Covariance of a belief target

[Environment Description]
Varying number of agents, varying number of randomly moving targets
No obstacles

setTrackingEnv0 : Double Integrator Target model with KF belief tracker
    obs state: [d, alpha, ddot, alphadot, logdet(Sigma), observed] *nb_targets
            where nb_targets and nb_agents vary between a range
            num_targets describes the upperbound on possible number of targets in env
            num_agents describes the upperbound on possible number of agents in env
    Target : Double Integrator model, [x,y,xdot,ydot]
    Belief Target : KF, Double Integrator model

"""

class setTrackingEnvBMKF(maTrackingBase):

    def __init__(self, num_agents=1, num_targets=2, map_name='empty', 
                        is_training=True, known_noise=True, multi_step=0, im_shape=(2, 20), r_rate=0.5,r_bias=0.5, **kwargs):
        super().__init__(num_agents=num_agents, num_targets=num_targets,
                        map_name=map_name, is_training=is_training)

        self.id = 'setTracking-v0'
        self.nb_agents = num_agents #only for init, will change with reset()
        self.nb_targets = num_targets #only for init, will change with reset()
        self.agent_dim = 3
        self.target_dim = 4
        self.target_init_vel = METADATA['target_init_vel']*np.ones((2,))
        self.im_shape = im_shape
        self.multi_step = multi_step
        self.action_cost = 0
        self.r_limit_m = r_rate*self.sensor_r
        wf_o = (self.r_limit_m+self.sensor_r)/2
        wf_r = (self.sensor_r-self.r_limit_m)/2
        wf_a = -1/(wf_r)**2
        alpha = 2/wf_r 
        self.weight_func = lambda x, obs: wf_a*(x-wf_o)**2+2+alpha if obs else alpha*math.e**(self.sensor_r-x)+1

        # LIMIT
        self.limit = {} # 0: low, 1:highs
        self.limit['agent'] = [np.concatenate((self.MAP.mapmin,[-np.pi])), np.concatenate((self.MAP.mapmax, [np.pi]))]
        self.limit['target'] = [np.concatenate((self.MAP.mapmin,[-METADATA['target_vel_limit'], -METADATA['target_vel_limit']])),
                                np.concatenate((self.MAP.mapmax, [METADATA['target_vel_limit'], METADATA['target_vel_limit']]))]
        rel_vel_limit = METADATA['target_vel_limit'] + METADATA['action_v'][0] # Maximum relative speed
        self.limit['state'] = [np.array(([0.0, -np.pi, -rel_vel_limit, -10*np.pi, -50.0, 0.0])),
                               np.array(([600.0, np.pi, rel_vel_limit, 10*np.pi, 50.0, 2.0]))]
        self.observation_space = spaces.Box(
            np.concatenate((-np.ones(5*self.im_shape[1]*self.im_shape[1],),self.limit['state'][0],[0.0, -np.pi])), 
            np.concatenate((-np.ones(5*self.im_shape[1]*self.im_shape[1],),self.limit['state'][1],[self.sensor_r, np.pi])), dtype=np.float32)
        self.targetA = np.concatenate((np.concatenate((np.eye(2), self.sampling_period*np.eye(2)), axis=1), 
                                        [[0,0,1,0],[0,0,0,1]])) #UNKNOWN: What's this?
        self.target_noise_cov = METADATA['const_q'] * np.concatenate((
                        np.concatenate((self.sampling_period**3/3*np.eye(2), self.sampling_period**2/2*np.eye(2)), axis=1),
                        np.concatenate((self.sampling_period**2/2*np.eye(2), self.sampling_period*np.eye(2)),axis=1) )) #UNKNOWN: What's this?
        if known_noise:
            self.target_true_noise_sd = self.target_noise_cov
        else:
            self.target_true_noise_sd = METADATA['const_q_true'] * np.concatenate((
                        np.concatenate((self.sampling_period**2/2*np.eye(2), self.sampling_period/2*np.eye(2)), axis=1),
                        np.concatenate((self.sampling_period/2*np.eye(2), self.sampling_period*np.eye(2)),axis=1) ))

        # Build a robot 
        self.setup_agents()
        # Build a target
        self.setup_targets()
        self.setup_belief_targets()
        # Use custom reward
        # self.get_reward()

    def setup_agents(self):
        self.agents = [AgentSE2(agent_id = 'agent-' + str(i), 
                        dim=self.agent_dim, sampling_period=self.sampling_period, 
                        limit=self.limit['agent'], 
                        collision_func=lambda x: map_utils.is_collision(self.MAP, x))
                        for i in range(self.num_agents)]

    def setup_targets(self):
        self.targets = [AgentDoubleInt2D(agent_id = 'target-' + str(i),
                        dim=self.target_dim, sampling_period=self.sampling_period, 
                        limit=self.limit['target'],
                        collision_func=lambda x: map_utils.is_collision(self.MAP, x),
                        A=self.targetA, W=self.target_true_noise_sd) 
                        for i in range(self.num_targets)]

    def setup_belief_targets(self):
        self.belief_targets = [PFbelief(agent_id = 'target-' + str(i),
                        dim=self.target_dim, limit=self.limit['target'], A=self.targetA,
                        W=self.target_noise_cov, obs_noise_func=self.observation_noise, 
                        multi_step= self.multi_step,
                        collision_func=lambda x: map_utils.is_collision(self.MAP, x))
                        for i in range(self.num_targets)]

    def get_reward(self, observed, is_training=True):
        return reward_fun(self.nb_targets, self.belief_targets, self.agents[:self.nb_agents], 0.1, observed, None, self.weight_func)

    def reset(self,**kwargs):
        """
        Random initialization a number of agents and targets at the reset of the env epsiode.
        Agents are given random positions in the map, targets are given random positions near a random agent.
        Return an observation state dict with agent ids (keys) that refer to their observation
        """
        self.rng = np.random.default_rng()

        self.action_cost = 0

        try: 
            self.nb_agents = kwargs['nb_agents']
            self.nb_targets = kwargs['nb_targets']
        except:
            self.nb_agents = np.random.random_integers(1, self.num_agents)
            self.nb_targets = np.random.random_integers(1, self.num_targets)
        obs_dict = {}
        init_pose = self.get_init_pose(**kwargs)
        # Initialize agents
        for ii in range(self.nb_agents):
            self.agents[ii].reset(init_pose['agents'][ii])
            obs_dict[self.agents[ii].agent_id] = []

        # Initialize targets and beliefs
        multi_step_dict = {}
        for nn in range(self.nb_targets):
            multi_step_dict[nn] = self.belief_targets[nn].reset(
                        init_state=np.concatenate((init_pose['targets'][nn][:2], np.zeros(2))),
                        init_cov=self.target_init_cov)
            self.targets[nn].reset(np.concatenate((init_pose['targets'][nn][:2], self.target_init_vel)))
        # For nb agents calculate belief of targets assigned
        for jj in range(self.nb_targets):
            for kk in range(self.nb_agents):
                r, alpha = util.relative_distance_polar(self.belief_targets[jj].state[:2],
                                            xy_base=self.agents[kk].state[:2], 
                                            theta_base=self.agents[kk].state[2])
                multi_step_b = []
                for after_state in multi_step_dict[jj]:
                    r_af, alpha_af = util.relative_distance_polar(after_state[:2],
                                        xy_base=self.agents[ii].state[:2], 
                                        theta_base=self.agents[ii].state[-1])
                    multi_step_b.extend([r_af, alpha_af])

                logdetcov = np.log(LA.det(self.belief_targets[jj].cov))
                obs_dict[self.agents[kk].agent_id].extend([r, alpha,*multi_step_b, 0.0, 0.0, logdetcov, 0.0])
        # For obstacles information
        for ii in range(self.nb_agents):
            obstacles_pt = map_utils.get_closest_obstacle(self.MAP, self.agents[ii].state)
            if obstacles_pt is None:
                obstacles_pt = (self.sensor_r, np.pi)
            obs_dict[self.agents[ii].agent_id].extend([obstacles_pt[0],obstacles_pt[1]])

        # For frequency map
        self.MAP.reset_belief_map()
        # Update the visit frequency map.
        # b_speed = np.mean([np.sqrt(np.sum(self.belief_targets[i].state[2:]**2)) for i in range(self.nb_targets)])
        # refresh_factor = np.exp(self.sampling_period*b_speed/self.sensor_r*np.log(0.7))
        map_utils.update_belief_map(self.MAP,self.agents,self.belief_targets,self.nb_agents,self.nb_targets)
        # for ii in range(self.nb_agents): 
        #     map_utils.update_scan_map(self.MAP,self.agents[ii].state)
        #     map_utils.update_uncertainty(self.MAP,self.agents[ii].state)
        # mask = self.MAP.scan_map == 1
        # self.belief_ratio = (mask*self.MAP.belief_map).sum()/self.MAP.belief_map.sum()

        self.belief_map = self.MAP.belief_map

        # Store belief map
        self.local_map = [[] for _ in range(self.nb_agents)]
        map_utils.update_global_map(self.MAP, self.im_shape[1])
        global_map = map_utils.get_global_map(self.MAP)
        for ii in range(self.nb_agents):
            _, self.local_map[ii] = map_utils.local_belief_map(
                                                    self.MAP,self.im_shape[1], self.agents[ii].state)
            # normalize the maps
            self.local_map[ii] = [(self.local_map[ii] - 0.5) * 2]
            self.local_map[ii].append(global_map)
            obs_dict[self.agents[ii].agent_id].extend(np.array(self.local_map[ii]).flatten().tolist())

        for agent_id in obs_dict:
            obs_dict[agent_id] = np.asarray(obs_dict[agent_id])
        return obs_dict

    def step(self, action_dict):
        obs_dict = {}
        reward_dict = {}
        done_dict = {'__all__':False}
        info_dict = {}

        # Targets move (t -> t+1)
        multi_step_dict = {}
        for n in range(self.nb_targets):
            self.targets[n].update() 
            multi_step_dict[n] = self.belief_targets[n].predict() # Belief state at t+1
        b_speed = np.mean([np.sqrt(np.sum(self.belief_targets[i].state[2:]**2)) for i in range(self.nb_targets)])
        decay_factor = np.exp(self.sampling_period*b_speed/self.sensor_r*np.log(0.7))
        self.MAP.decay_belief_map(decay_factor)

        # Agents move (t -> t+1) and observe the targets
        for ii, agent_id in enumerate(action_dict):
            assert self.agents[ii].agent_id == agent_id
            obs_dict[self.agents[ii].agent_id] = []
            reward_dict[self.agents[ii].agent_id] = []
            done_dict[self.agents[ii].agent_id] = []

            action_vw = self.action_map[action_dict[agent_id]]

            # Locations of all targets and agents in order to maintain a margin between them
            margin_pos = [t.state[:2] for t in self.targets[:self.nb_targets]]
            for p, ids in enumerate(action_dict):
                if agent_id != ids:
                    margin_pos.append(np.array(self.agents[p].state[:2]))
            _ = self.agents[ii].update(action_vw, margin_pos)
            
            # Target and map observations
            observed = np.zeros(self.nb_targets, dtype=bool)

            # Update beliefs of targets

            for jj in range(self.nb_targets):
                # Observe
                obs, z_t = self.observation(self.targets[jj], self.agents[ii])
                observed[jj] = obs
                if obs: # if observed, update the target belief.
                    self.belief_targets[jj].update(z_t, self.agents[ii].state)

                r_b, alpha_b = util.relative_distance_polar(self.belief_targets[jj].state[:2],
                                        xy_base=self.agents[ii].state[:2], 
                                        theta_base=self.agents[ii].state[-1])
                
                multi_step_b = []
                for after_state in multi_step_dict[jj]:
                    r_af, alpha_af = util.relative_distance_polar(after_state[:2],
                                        xy_base=self.agents[ii].state[:2], 
                                        theta_base=self.agents[ii].state[-1])
                    multi_step_b.extend([r_af, alpha_af])

                r_dot_b, alpha_dot_b = util.relative_velocity_polar(
                                        self.belief_targets[jj].state[:2],
                                        self.belief_targets[jj].state[2:],
                                        self.agents[ii].state[:2], self.agents[ii].state[-1],
                                        action_vw[0], action_vw[1])
                obs_dict[agent_id].extend([r_b, alpha_b,*multi_step_b, r_dot_b, alpha_dot_b,
                                        np.log(LA.det(self.belief_targets[jj].cov)), float(obs)])
            # shuffle obs to promote permutation invariance
            self.rng.shuffle(obs_dict[agent_id])
            obs_dict[agent_id] = np.array(obs_dict[agent_id]).flatten().tolist()
            obstacles_pt = map_utils.get_closest_obstacle(self.MAP, self.agents[ii].state)
            if obstacles_pt is None:
                obstacles_pt = (self.sensor_r, np.pi)
            obs_dict[agent_id].extend([obstacles_pt[0],obstacles_pt[1]])  

        # update belief map
        map_utils.update_belief_map(self.MAP,self.agents,self.belief_targets,self.nb_agents,self.nb_targets)
        
        self.belief_map = self.MAP.belief_map

        # Store frequency map
        self.local_map = [[] for _ in range(self.nb_agents)]
        map_utils.update_global_map(self.MAP, self.im_shape[1])
        global_map = map_utils.get_global_map(self.MAP)
        for ii in range(self.nb_agents):
            _, self.local_map[ii] = map_utils.local_belief_map(
                                                    self.MAP,self.im_shape[1], self.agents[ii].state)
            # normalize the maps
            self.local_map[ii] = [(self.local_map[ii] - 0.5) * 2]
            self.local_map[ii].append(global_map)
            obs_dict[self.agents[ii].agent_id].extend(np.array(self.local_map[ii]).flatten().tolist())

            obs_dict[self.agents[ii].agent_id] = np.asarray(obs_dict[self.agents[ii].agent_id])

        # Get all rewards after all agents and targets move (t -> t+1)
        reward, done, mean_nlogdetcov = self.get_reward(observed, self.is_training)
        reward_dict['__all__'], done_dict['__all__'], info_dict['mean_nlogdetcov'] = reward, done, mean_nlogdetcov
        return obs_dict, reward_dict, done_dict, info_dict

def reward_fun(nb_targets, belief_targets, agents, c_mean=0.1, observed=None, belief_ratio=None, weight_func=None):
    # min_dist = []
    # for b_target in belief_targets[:nb_targets]:
    #     r_min = 10000000
    #     for agent in agents:
    #         r, alpha = util.relative_distance_polar(b_target.state[:2],
    #                                             xy_base=agent.state[:2], 
    #                                             theta_base=agent.state[2])
    #         if r < r_min:
    #             r_min = r
    #     min_dist.append(r_min)
    # det_res = [LA.det(belief_targets[i].cov) for i in range(len(belief_targets[:nb_targets]))]
    # detcov = [weight_func(min_dist[i],observed[i])*np.log(LA.det(belief_targets[i].cov)) for i in range(len(belief_targets[:nb_targets]))]
    # detcov = [np.exp(belief_ratio[i]-1)*np.log(LA.det(belief_targets[i].cov)) for i in range(len(belief_targets[:nb_targets]))]
    detcov = [np.log(LA.det(belief_targets[i].cov)) for i in range(len(belief_targets[:nb_targets]))]
    r_detcov_mean = - np.mean(detcov)
    # r_detcov_mean = - np.exp(belief_ratio-1)*np.mean(detcov)
    reward = c_mean * r_detcov_mean

    try:
        if np.isnan(reward):
            print('error reward')
    except ValueError:
        print('do something')

    mean_nlogdetcov = None
    if True:
        logdetcov = [np.log(LA.det(b_target.cov)) for b_target in belief_targets[:nb_targets]]
        mean_nlogdetcov = -np.mean(logdetcov)
    return reward, False, mean_nlogdetcov