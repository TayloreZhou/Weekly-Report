import sys
import logging
import pathlib
from datetime import datetime
from pytz import timezone, utc


class LogHelper(object):
    '''
    A basic setting for logging
    log_path: the output file
    '''
    log_format = '%(asctime)s %(levelname)s - %(name)s - %(message)s'

    @staticmethod
    def setup(log_path, level='INFO'):
        # basic setting, for logging information to file(All)
        logging.basicConfig(filename=log_path,level=logging.getLevelName(level),format= LogHelper.log_format)

        # Set up logging to console
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.DEBUG)
        console_formatter = logging.Formatter(LogHelper.log_format)
        console_handler.setFormatter(console_formatter)
        # Add the console handler to the root logger
        logging.getLogger('').addHandler(console_handler)

        # Log for unhandled exception
        logger = logging.getLogger(__name__)
        sys.excepthook = lambda *ex: logger.critical('Unhandled exception', exc_info=ex)

        logger.info('Completed configuring logger.')