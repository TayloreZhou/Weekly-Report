import seaborn as sns
import os
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
sns.set_theme(style="whitegrid")

# load data
# SET_EVAL_v0 = [
#         {'nb_agents': 1, 'nb_targets': 1},
#         {'nb_agents': 2, 'nb_targets': 1},
#         {'nb_agents': 3, 'nb_targets': 1},
#         {'nb_agents': 4, 'nb_targets': 1},
#         {'nb_agents': 1, 'nb_targets': 2},
#         {'nb_agents': 2, 'nb_targets': 2},
#         {'nb_agents': 3, 'nb_targets': 2},
#         {'nb_agents': 4, 'nb_targets': 2},
#         {'nb_agents': 1, 'nb_targets': 3},
#         {'nb_agents': 2, 'nb_targets': 3},
#         {'nb_agents': 3, 'nb_targets': 3},
#         {'nb_agents': 4, 'nb_targets': 3},
#         {'nb_agents': 1, 'nb_targets': 4},
#         {'nb_agents': 2, 'nb_targets': 4},
#         {'nb_agents': 3, 'nb_targets': 4},
#         {'nb_agents': 4, 'nb_targets': 4},
# ]
SET_EVAL_v0 = [
        {'nb_agents': 1, 'nb_targets': 1},
        {'nb_agents': 1, 'nb_targets': 2},
]
set_names = []
for setting in SET_EVAL_v0:
    set_names.append('a{}t{}'.format(setting['nb_agents'],setting['nb_targets']))

set_mask = []
# for setting in SET_EVAL_v0:
#     if setting['nb_agents'] < setting['nb_targets']:
#         set_mask.append(1)
#     elif setting['nb_agents'] == setting['nb_targets']:
#         set_mask.append(2)
#     else:
#         set_mask.append(0)
for setting in SET_EVAL_v0:
    if setting['nb_agents']==1 and setting['nb_targets'] <=2:
        set_mask.append(0)
    else:
        set_mask.append(1)

draw_set = (0,)

res_file_a = './results/maTT/setTracking-vPf_07120218/seed_0'
res_file_b = './results/maTT/setTrackingBM-vKf_07112327/seed_0'
# res_file_b = './results/maTT/setTrackingWall-vPf_05240043/seed_0'
data_dict = {'Alg.':[],'MeanLogDetCov':[],'std':[],'type':[]}

result_dict = {}
result_dict['a'] = './results/maTT/setTracking-vPf_07192316/seed_0'
result_dict['b'] = './results/maTT/setTracking-vPf_07192316/seed_0'
result_dict['c'] = './results/maTT/setTracking-vPf_07192316/seed_0'
result_dict['d'] = './results/maTT/setTracking-vPf_07192316/seed_0'
test_count = 10

for al_name, results_dir in result_dict.items():
    # for Alg A:
    res_seed = []
    for i in range(test_count):
        path = os.path.join(results_dir,'eval_seed{}_test/all_1_eval1a4t.pkl'.format(i))
        fpath=open(path,"rb")
        rs = pickle.load(fpath)
        res_seed.append(rs)
    rs_mean = np.mean(res_seed,axis=0)
    rs_var = np.var(res_seed,axis=0)**0.5
    for j in range(len(rs)):
        if set_mask[j] in draw_set:
            data_dict['Alg.'].append(al_name)
            data_dict['MeanLogDetCov'].append(float(rs_mean[j]))
            data_dict['std'].append(rs_var[j])
            data_dict['type'].append(set_names[j])

data_df = pd.DataFrame(data_dict)
# Draw a nested barplot by species and sex
g = sns.catplot(
    data=data_df, kind="bar",
    x="type", y="MeanLogDetCov", hue="Alg.",
    ci="std", palette="dark", alpha=.6, height=6
)
g.despine(left=True)
g.set_axis_labels("", "MeanLogDetCov")
g.legend.set_title("")
plt.show()