import math
import matplotlib.pyplot as plt
import numpy as np
r_limit_m = 5
sensor_r =10
wf_o = (r_limit_m+sensor_r)/2
wf_r = (sensor_r-r_limit_m)/2
wf_a = -1/(wf_r)**2
alpha = 2/wf_r 
weight_func = lambda x: wf_a*(x-wf_o)**2+2+alpha if x<sensor_r else alpha*math.e**(sensor_r-x)+1 

x = np.linspace(0, 30, 400)
y = [weight_func(x[i]) for i in range(len(x))]

plt.plot(x, y)
plt.axhline(y=1,ls=":",c="red")#添加水平直线
plt.axvline(x=sensor_r,ls=":",c="red")#添加垂直直线
plt.axvline(x=r_limit_m,ls=":",c="red")#添加垂直直线
plt.axvline(x=(sensor_r+r_limit_m)/2.0,ls=":",c="red")#添加垂直直线
plt.xlabel('dist')
plt.ylabel('ratio')
plt.show()