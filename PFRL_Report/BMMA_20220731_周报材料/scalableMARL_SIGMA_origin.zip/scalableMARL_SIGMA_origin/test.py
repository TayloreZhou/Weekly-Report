import numpy as np
import cv2
import matplotlib.pyplot as plt
 
# axis_list = [[3,1],[2,2],[3,3],[4,4],[2,4]]
# axis_list = np.array(axis_list)
 
# hull = cv2.convexHull(axis_list,clockwise=True,returnPoints=True)
# print(hull)
# print(hull.shape)
 
# hull = np.squeeze(hull)
# plt.scatter(axis_list[:,0],axis_list[:,1])
# plt.plot(hull[:,0],hull[:,1],"r")
# plt.plot([hull[-1,0],hull[0,0]],[hull[-1,1],hull[0,1]],"r")
# plt.show()

from shapely.geometry import Point, LineString
from shapely.geometry import Polygon,MultiPoint  #多边形
import matplotlib.pyplot as plt
import numpy as np
import cv2
import math
point = Point(*(0, 3.0))
# axis_list= np.array([(0, 0), (2,2),(3, 0), (3, 3), (0, 3)])
points = np.array([(0, 0), (2,2),(3, 0), (3, 3), (0, 3)])
x_ = points[:,0]
y_ = points[:,0]
expansion = (1,1)
expansion_g = (1,1)
# four direction
for idx in np.argwhere(x_ == np.amax(x_)).flatten():
    x_[idx] = x_[idx] + expansion[0]
for idx in np.argwhere(x_ == np.amin(x_)).flatten():
    x_[idx] = x_[idx] - expansion[0]
for idx in np.argwhere(y_ == np.amax(y_)).flatten():
    y_[idx] = y_[idx] + expansion[1]
for idx in np.argwhere(y_ == np.amin(y_)).flatten():
    y_[idx] = y_[idx] - expansion[1]
points = np.vstack((x_,y_)).T
points = np.clip(points,[0,0],[3,3])
hull = cv2.convexHull(points,clockwise=True,returnPoints=True)
hull = np.squeeze(hull)
hull_valid = []
if len(hull) == 2:
    delta_x = hull[0][0] - hull[1][0]
    delta_y = hull[0][1] - hull[1][1]
    if delta_x == 0 and delta_y==0:
        pass
    elif delta_x == 0:
        hull_valid.append(hull[0]-[expansion_g[0],0])
        hull_valid.append(hull[0]+[expansion_g[0],0])
        hull_valid.append(hull[1]-[expansion_g[0],0])
        hull_valid.append(hull[1]+[expansion_g[0],0])
        hull = np.clip(hull_valid,[0,0],[3,3])
    elif delta_y==0:
        hull_valid.append(hull[0]-[0,expansion_g[1]])
        hull_valid.append(hull[0]+[0,expansion_g[1]])
        hull_valid.append(hull[1]-[0,expansion_g[1]])
        hull_valid.append(hull[1]+[0,expansion_g[1]])
        hull = np.clip(hull_valid,[0,0],[3,3])
    else:
        k = -delta_x/delta_y
        theta = math.atan(k)
        expansion_l = (expansion_g[0]**2+expansion_g[1]**2)**0.5
        bias = [round(expansion_l*math.cos(theta)),round(expansion_l*math.sin(theta))]
        hull_valid.append(hull[0]+bias)
        hull_valid.append(hull[0]-bias)
        hull_valid.append(hull[1]+bias)
        hull_valid.append(hull[1]-bias)
        hull = np.clip(hull_valid,[0,0],[3,3])
    print(hull.shape)
    hull = cv2.convexHull(hull,clockwise=True,returnPoints=True)
    hull = np.squeeze(hull)
# hull = cv2.convexHull(axis_list,clockwise=True,returnPoints=True)
poly = Polygon(np.squeeze(hull))
print(poly.area)
print(poly.covers(point))
ax = plt.gca()                                 #获取到当前坐标轴信息
ax.xaxis.set_ticks_position('top')   #将X坐标轴移到上面
ax.invert_yaxis()                            #反转Y坐标轴
plt.plot(*poly.exterior.xy)
plt.show()

# def func():
#     a = 10
#     def fa(b):
#         return b < a
#     return fa

# f = func()
# for i in range(5,15):
#     print(f(i))